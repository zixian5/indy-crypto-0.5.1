#ifndef __indy__crypto__cl__included__
#define __indy__crypto__cl__included__

#ifdef __cplusplus
extern "C" {
#endif

    /// TODO: FIXME: Probide list of interfaces for ffi/cl/mod.rs

#ifdef __cplusplus
}
#endif

#endif

