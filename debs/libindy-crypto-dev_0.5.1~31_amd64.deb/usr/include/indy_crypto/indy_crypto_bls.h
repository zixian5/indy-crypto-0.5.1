#ifndef __indy__crypto__bls__included__
#define __indy__crypto__bls__included__

#ifdef __cplusplus
extern "C" {
#endif

    /// TODO: FIXME: Probide list of interfaces for ffi/bls.rs

#ifdef __cplusplus
}
#endif

#endif

